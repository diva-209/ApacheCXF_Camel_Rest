/**
 * 
 */
package com.rest.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import com.rest.exceptions.DataNotFoundException;
import com.rest.exceptions.DataNotValidException;
import com.rest.exceptions.DuplicateRecordException;
import com.rest.valueobjects.Student;

/**
 * implements the functionality of the service methods.
 * 
 * @author dsiriki
 *
 */
public class StudentServiceDao {
	
	private Logger logger = Logger.getLogger(StudentServiceDao.class);
	
	private Map<Integer,Student> studentMap = new HashMap<Integer,Student>();
	
	// creating Student data while initialising dao object and maintaining cache to avoid multiple creations.
	public StudentServiceDao() {
		
		logger.debug("preparing student data while initializing StudentServiceDao class");
		
		if(studentMap.isEmpty()) {
		Student student = new Student();
		student.setStudentId(1);
		student.setStudentName("Divakar Siriki");
		student.setDepartName("eee");
		
		Student student2 = new Student();
		student2.setStudentId(2);
		student2.setStudentName("Satish");
		student2.setDepartName("cse");
		
		studentMap.put(1, student);
		studentMap.put(2, student2);
		}	
		
	}
	
	/**
	 * gets the student details with respect to studentId
	 * @param studentId
	 * @return Response object
	 */
	public Response getStudentDetails(int studentId) {
		
		logger.debug("entering into getStudentDetails operation");
		
		Student student = studentMap.get(studentId);
		if(student == null) {
			logger.debug("data not found for this studentId :"+studentId+" therefore throwing DataNotFoundException");
			throw new DataNotFoundException("Data not found with this studentId");
		}
		
		return Response.status(Response.Status.ACCEPTED).entity(student).type(MediaType.APPLICATION_JSON).build();
		
	}
	
	/**
	 * adds the student to the studentMap
	 */
	public Response addStudent(Student student) {
		logger.debug("entering into addStudent operation with studentId : "+student.getStudentId());
		
		if(studentMap.containsKey(student.getStudentId())) {
			logger.debug("Record for this student allready exists.Please try to update instead of adding");
			throw new DuplicateRecordException("Record Allready exists");
		} else {
			studentMap.put(student.getStudentId(), student);
		}
		
		return Response.status(Response.Status.ACCEPTED).entity("Successfully added into student records")
				.type(MediaType.TEXT_PLAIN).build();
	}
	
	/**
	 * deletes the student from database records.
	 * @param studentId
	 * @return Response
	 */
	public Response deleteStudent(int studentId) {
		logger.debug("entering into deleteStudent operation with studentId : "+studentId);
		
		if(!studentMap.containsKey(studentId)) {
			logger.debug("Record doesn't exist with this studentId:");
			throw new DataNotFoundException("Student record doesn't exist with this studentId : "+studentId);
			
		}else {
			studentMap.remove(studentId);
		}
		return Response.status(Response.Status.OK).entity("Student record deleted successfully")
				.type(MediaType.TEXT_PLAIN).build();
				
	}
	
	/**
	 * Retrieves the student based on studentId and updates his/her name with the updatedName
	 * @param studentId
	 * @param updatedName
	 * @return Response
	 */
	public Response updateStudent(int studentId,String updatedName) {
		
		logger.debug("entering updateStudent operation for studetnId : "+studentId);
		Student student = null;
		if(!studentMap.containsKey(studentId)) {
			logger.debug("Record doesn't exist with this studentId:");
			throw new DataNotFoundException("Student record doesn't exist with this studentId : "+studentId);
			
		} else {
			student = studentMap.get(studentId);
			student.setStudentName(updatedName);
		}
		
		return Response.status(Response.Status.OK).entity(student).type(MediaType.APPLICATION_JSON).build();
		
	}
	
	/**
	 * gets the students from the given range of studentIds
	 * @param fromId
	 * @param toId
	 * @return Response
	 */
	public Response getStudents(int fromId,int toId) {
		logger.debug("entering getStudents operation from studentId : "+fromId+" to studentId : "+toId);
		
		if(fromId < 1) {
			logger.debug("minimum value for studentId should be 1");
			throw new DataNotValidException("Minimum value for studentId should be 1");
		}
		List<Student> students = new ArrayList<Student>();
		for(int i=fromId;i<=toId;i++) {
			Student student = studentMap.get(i);
			students.add(student);
		}
		
		return Response.status(Response.Status.OK).entity(students).type(MediaType.APPLICATION_JSON).build();
	}

}
