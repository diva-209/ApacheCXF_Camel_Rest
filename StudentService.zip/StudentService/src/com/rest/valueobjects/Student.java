/**
 * 
 */
package com.rest.valueobjects;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Representation object to hold Student data
 * 
 * @author dsiriki
 *
 */
@XmlRootElement
public class Student {
	
	private int studentId;
	
	private String studentName;
	
	private String departName;

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getDepartName() {
		return departName;
	}

	public void setDepartName(String departName) {
		this.departName = departName;
	}
	
	

}
