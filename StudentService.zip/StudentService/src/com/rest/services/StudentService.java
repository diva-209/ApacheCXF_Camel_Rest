/**
 * 
 */
package com.rest.services;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.common.util.ReflectionInvokationHandler.UnwrapParam;
import org.springframework.web.bind.annotation.DeleteMapping;

import com.rest.valueobjects.Student;

/**
 * @author dsiriki
 *
 */
@Path("studentservice")
public interface StudentService {
	
	@GET
	@Path("getstudent/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStudentDetails(@PathParam("id") int studentId);
	
	@GET
	@Path("getstudents")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStudents(@QueryParam("fromId") int fromId,@QueryParam("toId") int toId);
	
	@POST
	@Path("addstudent")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addStudent(Student student);
	
	@DELETE
	@Path("deletestudent/{id}")
	public Response deleteStudent(@PathParam("id") int studentId);
	
	@PUT
	@Path("updatestudent")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateStudent(@FormParam("id") int studentId,@FormParam("updatedName") String updatedName);

}
