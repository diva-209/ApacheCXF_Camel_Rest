/**
 * 
 */
package com.rest.impl;

import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.dao.StudentServiceDao;
import com.rest.services.StudentService;
import com.rest.valueobjects.Student;

/**
 * Implementation class for StudentService api.
 * 
 * @author dsiriki
 *
 */
@Service("studentserviceBean")
public class StudentServiceImpl implements StudentService {
	
	private Logger logger = Logger.getLogger(StudentServiceImpl.class);
	
	@Autowired
	private StudentServiceDao studentDao;

	/* (non-Javadoc)
	 * @see com.rest.services.StudentService#getStudentDetails(int)
	 */
	@Override
	public Response getStudentDetails(int studentId) {
		logger.debug("invoking getStudentDetails operation with studentId : "+studentId);
		return studentDao.getStudentDetails(studentId);
		
	}

	/* (non-Javadoc)
	 * @see com.rest.services.StudentService#addStudent(com.rest.valueobjects.Student)
	 */
	@Override
	public Response addStudent(Student student) {
		logger.debug("invoking addStudent operation");
		return studentDao.addStudent(student);
	}

	/* (non-Javadoc)
	 * @see com.rest.services.StudentService#deleteStudent(int)
	 */
	@Override
	public Response deleteStudent(int studentId) {
		logger.debug("invoking deleteStudent operation");
		return studentDao.deleteStudent(studentId);
	}

	/* (non-Javadoc)
	 * @see com.rest.services.StudentService#updateStudent(com.rest.valueobjects.Student)
	 */
	@Override
	public Response updateStudent(int studentId, String updatedName) {
		logger.debug("invoking updateStudent operation");
		return studentDao.updateStudent(studentId,updatedName);
	}

	@Override
	public Response getStudents(int fromId, int toId) {
		logger.debug("invoking getStudents operation and retrieves student records in the given range");
		return studentDao.getStudents(fromId,toId);
	}

}
