/**
 * 
 */
package com.rest.exceptions;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;



/**
 * Handler to map the custom exception and send as json response to the client
 * 
 * @author dsiriki
 *
 */
@Provider
public class DuplicateRecordExceptionHandler implements ExceptionMapper<DuplicateRecordException>{

	@Override
	public Response toResponse(DuplicateRecordException exception) {
		return Response.status(404).entity(new ErrorHandler("404",exception.getMessage())).type(MediaType.APPLICATION_JSON).build();
	}

}
