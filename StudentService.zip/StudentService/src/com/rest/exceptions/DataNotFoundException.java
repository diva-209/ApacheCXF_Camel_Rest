/**
 * 
 */
package com.rest.exceptions;

import java.io.Serializable;

/**
 * Custom exception which handles when data is not found.
 * 
 * @author dsiriki
 *
 */
public class DataNotFoundException extends RuntimeException implements Serializable{
	
	/**
	 * serialVersionUid
	 */
	private static final long serialVersionUID = 1L;

	public DataNotFoundException(String errorMessage) {
		super(errorMessage);
	}
}
