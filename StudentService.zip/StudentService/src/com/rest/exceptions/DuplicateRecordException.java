/**
 * 
 */
package com.rest.exceptions;

/**
 * Custom Exception to handle Duplicate Records insertion.
 * 
 * @author dsiriki
 *
 */
public class DuplicateRecordException extends RuntimeException {

	private String errorMessage;

	public DuplicateRecordException(String errorMessage) {

		super(errorMessage);
	}

}
