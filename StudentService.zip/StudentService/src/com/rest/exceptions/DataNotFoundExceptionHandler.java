/**
 * 
 */
package com.rest.exceptions;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 * 
 * @author dsiriki
 *
 */
@Provider
public class DataNotFoundExceptionHandler implements ExceptionMapper<DataNotFoundException>{

	@Override
	public Response toResponse(DataNotFoundException exception) {
		return Response.status(404).entity(new ErrorHandler("404",exception.getMessage())).type(MediaType.APPLICATION_JSON).build();
	}

}
