/**
 * 
 */
package com.rest.exceptions;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

/**
 * Exception Mapper for giving readable json error response to user
 * 
 * @author dsiriki
 *
 */
public class DataNotValidExceptionHandler implements ExceptionMapper<DataNotValidException>{

	@Override
	public Response toResponse(DataNotValidException exception) {
		// TODO Auto-generated method stub
		return Response.status(Response.Status.BAD_REQUEST).entity(new ErrorHandler("400", exception.getMessage()))
				.type(MediaType.APPLICATION_JSON).build();
				
	}
	
	

}
