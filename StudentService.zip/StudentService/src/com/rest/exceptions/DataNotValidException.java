/**
 * 
 */
package com.rest.exceptions;

/**
 * custom exception for handling invalid data
 * 
 * @author dsiriki
 *
 */
public class DataNotValidException extends RuntimeException {

	public DataNotValidException(String errorMessage) {
		super(errorMessage);
	}

}
