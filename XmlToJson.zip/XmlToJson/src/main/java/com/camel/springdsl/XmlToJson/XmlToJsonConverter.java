package com.camel.springdsl.XmlToJson;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.spring.SpringCamelContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Initialises the camelcontext and starts the route which converts xml input to json
 * and prints to console.
 * 
 * @ Divakar Siriki
 *
 */
public class XmlToJsonConverter 
{
    public static void main( String[] args ) throws Exception
    {
    	String xmlString = "<Employee><name>Divakar</name><company>capgemini</company></Employee>";
        ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("camel-context.xml");
        
        
        CamelContext camelContext = SpringCamelContext.springCamelContext(ctx, false);
        try {
        camelContext.start();
        ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
        
        producerTemplate.sendBody("direct:marshal", xmlString);
        
        } finally {
        	camelContext.stop();
        	ctx.close();
        }
        
    }
}
